package com.tastypizza.decorator;

abstract class Toppings extends Pizza {
	public abstract String getDesc();
}
