package com.tastypizza.decorator;

public abstract class Drinks {
	String name;
	int calories;
	double price;
	public abstract double getPrice();
	public abstract int getcalories();
	
}
